/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdio.h"
#include "math.h"
#include "bmp.h"
#include "TDOA.h"
#include "oled.h"
#include "string.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
uint32_t time = 0;
int t1=0,t2=0,t3=0,t4=0,signA=0,signB=0,signC=0,signD=0;


double arv1=0,arv2=0;
double sum1=0,sum2=0;

uint8_t A[3];
uint8_t B[3];

int flag = 1;
float a[41] = {0},b[41] = {0};
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
int fputc(int ch,FILE *f)
{
	uint8_t temp[1] = {ch};
	HAL_UART_Transmit(&huart1, temp, 1, 2);
	return ch;
}
void delay_us(uint32_t us)//ֻ������F1ϵ��72M��Ƶ
{
    uint32_t delay = (HAL_RCC_GetHCLKFreq() / 4000000 * us);
    while (delay--)
	{
		;
	}
}
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
extern void TDOA_distance(float t21,float t31,float t41);
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
//�������������ʱ���
void Find_Square(float ctime1,float ctime2)
{
	int count,i=0;
  double x = 0,y = 0;
	
   for(x=0.0; x<=40.0; x++)
    {
        for(y=0.0; y<=40.0;y++)
        {
            if(fabs(sqrt(x*x+(y-40)*(y-40))-sqrt(x*x +y*y)-34000*ctime1)<3 && fabs(sqrt(x*x +y*y)-sqrt((40-x)*(40-x)+y*y)-34000*ctime2)<3)  
             {  
                    a[i]=x;
                    b[i]=y;
                    i++;
                    count =i;
//                printf("x=%.2f  y=%.2f count=%d\n",x,y,count);
             }  
        }
    }
//		count=Del_Zero(a,count);
//		Del_Zero(b,count);

        for(int i=0; i< count; i++)
        {
            sum1=sum1+a[i];
            sum2=sum2+b[i];
        }
				  arv1=sum1/count;
          arv2=sum2/count;
          printf("x=%.2f y=%.2f\n",arv1,arv2);
				  printf("\r\n");
			   	sum1=0;sum2=0;
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  MX_TIM2_Init();
  MX_I2C1_Init();
  /* USER CODE BEGIN 2 */
	TDOA_Init(&TDOA_S);
	HAL_TIM_Base_Start_IT(&htim2); 
	OLED_Init();
	OLED_Display_On();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {	
			if(signA&&signB&&signC&&signD)
					{
             
	         TDOA_Get_distanceANDangle(&TDOA_S);
						
            
						HAL_Delay(800);
						EXTI->IMR |= GPIO_PIN_0; 
						EXTI->IMR |= GPIO_PIN_1;
						EXTI->IMR |= GPIO_PIN_3;
						EXTI->IMR |= GPIO_PIN_11;
						signA = 0; signB = 0; signC = 0;signD = 0;
						flag = 1;
					}
		}

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
				
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{

		 if (htim->Instance == htim2.Instance)
		 {

					time++;	 
			
		 }
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_pin)
{
	if(flag == 1)
	{
	  time = 0;
		flag = 0;
	}
	
		if(GPIO_pin==GPIO_PIN_0)//Voice1
		{
				t1=time;;
				signA=1;
			
				EXTI->IMR &= ~(GPIO_PIN_0);
		}
		 if(GPIO_pin==GPIO_PIN_1)//Voice2
		{			
				t2=time;
			  signB=1;
			 
			  EXTI->IMR &= ~(GPIO_PIN_1); 
		}
		if(GPIO_PIN_3 == GPIO_pin)//Voice3
			{
				
				t3=time;
			  signC=1;
	
			  EXTI->IMR &= ~(GPIO_PIN_3); 
			}
		if(GPIO_pin==GPIO_PIN_11)//Voice4
		  {	
				t4=time;
			  signD=1;
		
			  EXTI->IMR &= ~(GPIO_PIN_11); 
		  }
	
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
	
  while (1)
  {
		
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
