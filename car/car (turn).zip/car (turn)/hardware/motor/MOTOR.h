#ifndef __MOTOR_H
#define	__MOTOR_H


void UP();
void DOWN();
void OK();
void RIGHT();
void LEFT();

#endif